package com.toadnamedduck.agentsoficecrown.blockentity;

import com.toadnamedduck.agentsoficecrown.Constants;
import com.toadnamedduck.agentsoficecrown.block.ModBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> MOD_BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, Constants.MODID);

    public static final Supplier<BlockEntityType<AltarBlockEntity>> ALTAR_BLOCK_ENTITY = MOD_BLOCK_ENTITIES.register("altar_block_entity", () ->
            BlockEntityType.Builder.of(
                    AltarBlockEntity::new,
                    ModBlocks.ALTAR.get())
                    .build(null)
    );

    public static final Supplier<BlockEntityType<SoulCondenserBlockEntity>> SOUL_CONDENSER_ENTITY = MOD_BLOCK_ENTITIES.register("soul_condenser_block_entity", () ->
            BlockEntityType.Builder.of(
                    SoulCondenserBlockEntity::new,
                    ModBlocks.SOUL_CONDENSER.get())
                    .build(null)
            );

    public static void register(IEventBus modEventBus){
        MOD_BLOCK_ENTITIES.register(modEventBus);
    }

}
