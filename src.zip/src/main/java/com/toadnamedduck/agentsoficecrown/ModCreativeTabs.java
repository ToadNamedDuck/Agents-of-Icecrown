package com.toadnamedduck.agentsoficecrown;

import com.toadnamedduck.agentsoficecrown.item.ModBlockItems;
import com.toadnamedduck.agentsoficecrown.item.ModItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import static com.toadnamedduck.agentsoficecrown.ModTranslatableComponents.MOD_CREATIVE_TAB;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Constants.MODID);
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> ICECROWN_TAB = CREATIVE_MODE_TABS.register("icecrown_tab",
            () -> CreativeModeTab.builder()
                    .title(MOD_CREATIVE_TAB)
                    .icon(() -> new ItemStack(ModBlockItems.BLOCK_OF_SARONITE.get()))
                    .displayItems((params, output) -> {
                        for(DeferredHolder<Item, ? extends Item> block: ModBlockItems.BLOCK_ITEMS.getEntries()){
                            output.accept(block.get());
                        }
                        for(DeferredHolder<Item, ? extends Item> item: ModItems.MOD_ITEMS.getEntries()){
                            output.accept(item.get());
                        }


                    })
                    .build()
            );

    public static void register(IEventBus modEventBus){
        CREATIVE_MODE_TABS.register(modEventBus);
    }
}
