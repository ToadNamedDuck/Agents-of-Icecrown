package com.toadnamedduck.agentsoficecrown.datagen;

import com.toadnamedduck.agentsoficecrown.block.ModBlocks;
import com.toadnamedduck.agentsoficecrown.item.ModItems;
import net.minecraft.data.PackOutput;
import net.neoforged.fml.common.Mod;


public class ModEnUsLanguageProvider extends ModLanguageProvider {
    public ModEnUsLanguageProvider(PackOutput output){
        super(output, "en_us");
    }

    @Override
    protected void addLocaleTranslations() {
        //Items
        addItemToList(ModItems.RAW_SARONITE_ORE, "Raw Saronite Ore");
        addItemToList(ModItems.LIQUID_SARONITE_BUCKET, "Bucket of Liquid Saronite");
        addItemToList(ModItems.SARONITE_INGOT, "Saronite Ingot");
        addItemToList(ModItems.SARONITE_NUGGET, "Saronite Nugget");
        addItemToList(ModItems.SARONITE_SWORD, "Saronite Sword");
        addItemToList(ModItems.SARONITE_AXE, "Saronite Axe");
        addItemToList(ModItems.SARONITE_WING, "Saronite Wing");
        addItemToList(ModItems.COALESCED_SOULS, "Coalesced Souls");
        //Blocks
        addBlockToList(ModBlocks.BLOCK_OF_SARONITE, "Block of Saronite");
        addBlockToList(ModBlocks.LIQUID_SARONITE, "Liquid Saronite");
        addBlockToList(ModBlocks.RUNEFORGE, "Runeforge");
        addBlockToList(ModBlocks.SARONITE_ORE, "Saronite Ore");
        addBlockToList(ModBlocks.DEEPSLATE_SARONITE_ORE, "Deepslate Saronite Ore");
        addBlockToList(ModBlocks.ALTAR, "Unholy Altar");
        addBlockToList(ModBlocks.SOUL_CONDENSER, "Soul Condenser");
        //Entities

        //Ritual
        addByKey("altarritual.agentsoficecrown.in_progress", "There is a ritual already in progress.");
        addByKey("altarritual.agentsoficecrown.altar_empty", "You cannot perform a ritual on nothing.");
        addByKey("altarritual.agentsoficecrown.altar_wrong_item", "This item cannot be used in the ritual.");
        addByKey("altarritual.agentsoficecrown.altar_already_bound", "This weapon is already bound to someone.");
        addByKey("altarritual.agentsoficecrown.health_too_low", "You need more health to perform this ritual.");
        addByKey("altarritual.agentsoficecrown.ritual_not_prepared", "The ritual site is not adequate.");
        addByKey("altarritual.agentsoficecrown.ritual_cancelled", "The ritual has been cancelled. Coward.");
        addByKey("altarritual.agentsoficecrown.ritual_successful", "This weapon is now bound to you. Conquer now.");

        //Death Messages

        //Advancements

        //GUIs
        addByKey("gui.agentsoficecrown.soul_cond_title", "Soul Condenser");

        //Tooltips
        addByKey("tooltip.agentsoficecrown.inert", "Inert");
        addByKey("tooltip.agentsoficecrown.souls", "Souls: %s (+%s damage)");
        addByKey("tooltip.agentsoficecrown.soulbinding_owner_mismatch", "This weapon resists your command.");
        addByKey("tooltip.agentsoficecrown.soulbinding_durability_spent", "Repair this damaged weapon at a Runeforge.");
        addByKey("tooltip.agentsoficecrown.coalesced_souls_tooltip", "Sneak right-click to store souls in your soulbound weapon in the other hand.");

        //Misc - Creative Mode Tab
        addByKey("creativetab.agentsoficecrown.icecrown_tab", "Agents of Icecrown");
        addByKey("item.agentsoficecrown.coalesced_souls_no_binding", "Put a soulbound weapon that belongs to you in the other hand!");
    }

}
