package com.toadnamedduck.agentsoficecrown.datagen;

import com.toadnamedduck.agentsoficecrown.Constants;
import com.toadnamedduck.agentsoficecrown.block.ModBlocks;
import com.toadnamedduck.agentsoficecrown.block.RuneforgeBlock;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.neoforged.neoforge.client.model.generators.BlockStateProvider;
import net.neoforged.neoforge.client.model.generators.ModelFile;
import net.neoforged.neoforge.common.data.ExistingFileHelper;

public class ModBlockStateProvider extends BlockStateProvider {
    public ModBlockStateProvider(PackOutput output, ExistingFileHelper existingFileHelper){
        super(output, Constants.MODID, existingFileHelper);
    }



    @Override
    protected void registerStatesAndModels(){
        //Custom models
        ModelFile runeforgeBottomModel = models().getExistingFile(modLoc("block/runeforge_bottom"));
        ModelFile runeforgeTopModel = models().getExistingFile(modLoc("block/runeforge_top"));
        ModelFile altarModel = models().getExistingFile(modLoc("block/altar"));

        //Change model for runeforge based on state
        horizontalBlock(ModBlocks.RUNEFORGE.get(),state -> {
            if(state.getValue(RuneforgeBlock.HALF) == DoubleBlockHalf.LOWER){
                return runeforgeBottomModel;
            }
            else{
                return runeforgeTopModel;
            }
        });


        //Items for blocks using custom models
        itemModels().withExistingParent("runeforge", modLoc("item/runeforge_combined_item"));
        itemModels().withExistingParent("altar", modLoc("block/altar"));

        //Simple Blocks
        simpleBlockWithItem(ModBlocks.BLOCK_OF_SARONITE.get(), models().cubeAll("block_of_saronite", ResourceLocation.fromNamespaceAndPath(Constants.MODID,"block/block_of_saronite")));
        simpleBlockWithItem(ModBlocks.SARONITE_ORE.get(), models().cubeAll("saronite_ore", ResourceLocation.fromNamespaceAndPath(Constants.MODID, "block/saronite_ore")));
        simpleBlockWithItem(ModBlocks.DEEPSLATE_SARONITE_ORE.get(), models().cubeAll("deepslate_saronite_ore", ResourceLocation.fromNamespaceAndPath(Constants.MODID, "block/deepslate_saronite_ore")));
        simpleBlock(ModBlocks.ALTAR.get(), altarModel);
        simpleBlockWithItem(ModBlocks.SOUL_CONDENSER.get(), models().cubeBottomTop("soul_condenser", ResourceLocation.fromNamespaceAndPath(Constants.MODID, "block/soul_condenser_side"),
                ResourceLocation.fromNamespaceAndPath(Constants.MODID, "block/soul_condenser_bottom"), ResourceLocation.fromNamespaceAndPath(Constants.MODID, "block/soul_condenser_top")));
    }
}
